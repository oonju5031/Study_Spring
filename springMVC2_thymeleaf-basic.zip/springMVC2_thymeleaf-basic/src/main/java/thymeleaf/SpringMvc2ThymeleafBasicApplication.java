package thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvc2ThymeleafBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvc2ThymeleafBasicApplication.class, args);
	}

}
